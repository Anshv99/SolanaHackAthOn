const HtmlWebpackPlugin = require ('hml-webpack-plugin');
const path = require ('path');

module.exports = {
    mode: 'development',
    devtool: 'eval-source-map',
    entry: '.'
}